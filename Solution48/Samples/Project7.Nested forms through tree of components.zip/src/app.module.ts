import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { RootFormComponent } from './sample/root-form.component';
import { NestedFormComponent } from './sample/nested-form.component';
import { ReactiveFormComponent } from './sample/reactive-form.component';
import { IsolatedFormComponent } from './sample/isolated-form.component';

import { NestableFormDirective } from './forms/nestable-form.directive';
import { FormStatusComponent } from './forms/form-status.component';

@Component({
  selector: 'my-app',
  template: `
    <div>
      <h1>Nestable forms in Angular 4</h1>
      <root-form></root-form>
    </div>
  `,
})
export class App {
}

@NgModule({
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  declarations: [App,
    RootFormComponent,
    NestedFormComponent,
    ReactiveFormComponent,
    IsolatedFormComponent,
    NestableFormDirective,
    FormStatusComponent],
  bootstrap: [App]
})
export class AppModule {
}