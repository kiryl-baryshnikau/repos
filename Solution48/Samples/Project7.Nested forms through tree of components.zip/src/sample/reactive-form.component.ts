import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { NestableFormDirective } from '../forms/nestable-form.directive';

@Component({
  selector: 'reactive-form',
  template: `
    <div [formGroup]="sampleForm" nestableForm #form3="ngForm">
      <h3>Reactive form</h3>
      <form-status formName="form-3" [isFormValid]="form3.valid"></form-status>
      <input type="text" name="text3" formControlName="input3">

      <ngForm nestableForm #form31="ngForm" required>
        <form-status formName="form-3.1" [isFormValid]="form31.valid"></form-status>
        <input type="text" name="text31" ngModel required>
      </ngForm>

    </div>
  `,
})
export class ReactiveFormComponent implements OnInit {

  private sampleForm: FormGroup;

  constructor(private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.sampleForm = this.formBuilder.group({
      input3: ['', Validators.required],
    });
  }

}
