import { Component } from '@angular/core';

@Component({
  selector: 'root-form',
  template: `
    <form nestableForm #form1="ngForm">
      <form-status formName="form-1" [isFormValid]="form1.valid"></form-status>
      <nested-form></nested-form>
    </form>
  `,
})
export class RootFormComponent {

}
